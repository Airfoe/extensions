import sys

import bpy  # type: ignore

# preferences
from .preferences import P4Blender_Preferences

# operators
from .operators.P4_OT_Checkout import (
    P4_OT_CheckoutConfirm,
    P4_OT_CheckoutCurrent,
    P4_OT_CheckoutFile,
    P4_OT_DetectWorkspace,
    P4_OT_ShowStatus,
    P4_OT_TestConnection,
)
from .operators.P4_OT_Submit import P4_OT_SubmitFile

# menus and panels
from .ui.TOPBAR_MT_P4 import (
    TOPBAR_MT_p4_menu,
    draw_file_menu_entry,
)
from .ui.VIEW3D_PT_P4 import VIEW3D_PT_p4_panel

# handlers
from .handlers.save_handler import register_handlers, unregister_handlers

# public API, exposed under a stable name so other add-ons can find it
# regardless of which repository this was installed into
from . import api

API_ALIAS = "p4blender"


# reading values such as name, version and more from toml so there is no need
# to change information in two places
def load_manifest_info():
    from .constants import get_manifest

    manifest = get_manifest()

    version_tuple = tuple(int(x) for x in manifest["version"].split("."))
    blender_version_tuple = tuple(int(x) for x in manifest["blender_version_min"].split("."))

    return {
        "name": manifest["name"],
        "version": version_tuple,
        "blender": blender_version_tuple,
    }


blender_manifest = load_manifest_info()
bl_info = {
    "name": blender_manifest["name"],
    "description": "Checks the current .blend out of Perforce when you save",
    "author": "Fxnarji",
    "version": blender_manifest["version"],
    "blender": blender_manifest["blender"],
    "location": "Preferences > Add-ons",
    "support": "COMMUNITY",
    "category": "System",
}

classes = [
    # preferences
    P4Blender_Preferences,
    # operators:
    P4_OT_CheckoutConfirm,
    P4_OT_CheckoutCurrent,
    P4_OT_CheckoutFile,
    P4_OT_DetectWorkspace,
    P4_OT_ShowStatus,
    P4_OT_SubmitFile,
    P4_OT_TestConnection,
    # menus and panels:
    TOPBAR_MT_p4_menu,
    VIEW3D_PT_p4_panel,
]


def register():
    for i in classes:
        bpy.utils.register_class(i)

    bpy.types.TOPBAR_MT_file.append(draw_file_menu_entry)

    register_handlers()

    # Publish the API. setdefault rather than assignment so a stale alias from
    # a half-finished reload cannot be silently replaced by a second copy.
    sys.modules.setdefault(API_ALIAS, api)


def unregister():
    # handlers first: a handler firing against unregistered operators would
    # be a confusing failure right as the addon is going away
    unregister_handlers()

    # only withdraw the alias if it is still ours
    if sys.modules.get(API_ALIAS) is api:
        del sys.modules[API_ALIAS]

    bpy.types.TOPBAR_MT_file.remove(draw_file_menu_entry)

    for i in reversed(classes):
        bpy.utils.unregister_class(i)


if __name__ == "__main__":
    register()
