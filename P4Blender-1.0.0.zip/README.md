# P4Blender

Keeps the current `.blend` checked out of Perforce, submits it, and exposes a
small API so other add-ons (exporters, pipeline tools) can do the same for the
files they write.

Shells out to the `p4` command line client. No `p4python` dependency.

Requires Blender 4.2+ and the Perforce CLI on `PATH` (or in a standard install
location — the add-on also checks `C:\Program Files\Perforce\p4.exe` and the
usual Unix paths).

## What it does on save

A `@persistent` handler on `save_pre` checks whether the file is open for edit
and resolves it. What happens next depends on whether the save would otherwise
fail:

| File state | Behaviour |
| --- | --- |
| Open for edit | Nothing. |
| Read-only, not open | Checked out **inline, before the write**, no dialog. |
| Writable, not open | Deferred confirmation dialog, after the save. |
| Open by another user | Warning; still offers to check out (Perforce permits both). |
| Not in the depot | Reported, nothing to check out. |
| Server unreachable, no workspace, etc. | Reported; the save proceeds. |

The split exists because Perforce leaves unopened files **read-only**. A save
against one fails outright, and a confirmation dialog cannot be shown before
the write — `save_pre` runs inside the save, where modal dialogs cannot run.
Deferring the checkout in that case would mean the save it was meant to protect
fails every time. So read-only files are checked out silently and writable ones
— where the save succeeds either way — get the prompt.

Set `Auto Check Out Read-Only Files` to off in the preferences to be asked
instead, at the cost of the first save on each file failing.

**The handler never raises.** An exception escaping `save_pre` aborts the save
and costs you your work, so every path is wrapped; the worst case is a line in
the console and a save that proceeds without Perforce.

## Submitting

`File > Perforce > Submit`, or the sidebar panel. Takes a description, saves
first if the file is dirty, then submits **that one file** — not the default
changelist, which would sweep up unrelated open files.

It handles the common case only and refuses anything needing a human decision:

| Situation | Response |
| --- | --- |
| Not checked out | Refused — nothing to submit |
| In a numbered changelist | Refused — submit it from P4V |
| Unresolved changes | Refused — resolve in P4V first |
| Out of date | Refused — sync and resolve in P4V first |
| Open for delete / integrate | Refused |
| Open by you *and* someone else | Allowed — normal Perforce; they resolve |

A `.blend` is binary, so an out-of-date submit means someone's work is
discarded. That is not a choice this add-on makes for you.

## Connection settings

Resolved **environment first, preferences second**, per variable:

1. `P4PORT` / `P4USER` / `P4CLIENT` from the environment
2. the matching field in the add-on preferences

Whatever resolves is passed explicitly as `-p` / `-u` / `-c`, because a
subprocess launched from Blender may not inherit your shell's Perforce
configuration. Anything that resolves to nothing is left off the command line
entirely, so `p4` falls back to its own sources — the Windows registry (`p4
set`) or a `P4CONFIG` file. Those are invisible to the add-on but perfectly
valid, which is why **leaving the preference fields blank is normal**.

`p4` is run with its working directory set to the `.blend`'s own folder so a
`P4CONFIG` file in the workspace is found.

`P4PORT` wants the whole connection string including protocol, e.g.
`ssl:perforce.example.com:1666`.

### Diagnostics

The preferences panel has:

- **Test Connection** — runs `p4 set` and `p4 info`, showing what p4 will
  *actually* use and where each value came from. Use this rather than guessing
  from the preference fields.
- **Detect Workspace** — probes each of your workspaces with `p4 where` and
  stores the one that maps the current file.

## Interface

- **View3D sidebar (N) → Perforce** — state, revision, other users holding the
  file, Refresh / Check Out / Submit.
- **File → Perforce** — status, check out, submit.
- **Preferences** — connection fields, behaviour toggles, diagnostics.

Panels never shell out to `p4`; they read the status cached by the last check,
which the save handler refreshes anyway. Press Refresh if the file changed
underneath you.

## API for other add-ons

Registered in `sys.modules` as `p4blender` while the add-on is enabled, so
consumers do not need to know the real module name (which varies with the
repository it was installed into — `bl_ext.user_default.P4Blender`,
`bl_ext.vscode_development.P4Blender`, ...).

```python
import p4blender

p4blender.available()               # -> bool: enabled and p4 found
p4blender.checkout(path)            # -> bool
p4blender.status(path)              # -> "open" | "not_open" | "other_user"
                                    #    | "not_in_depot" | "no_file" | "error"
p4blender.submit(path, description) # -> bool
p4blender.API_VERSION               # -> (1, 0)
```

`checkout()` picks the right Perforce verb, which is what makes it usable
around an export:

- path does not exist yet → `True`, no p4 call (nothing blocks writing it)
- exists, not in the depot → `p4 add`
- exists, in the depot → `p4 edit`
- already open → `True`, no p4 call

So an exporter calls it on both sides and never has to know which case it is
in:

```python
p4blender.checkout(fbx_path)   # unlock an existing file; no-op if new
export_fbx(fbx_path)
p4blender.checkout(fbx_path)   # add it if it was newly created
```

Nothing in the API raises. Bad input, missing `p4`, a disabled add-on and a
dead server all return `False` and log the detail to the console, so a Perforce
problem cannot take down the caller.

### Using it without a hard dependency

Never `import p4blender` at module level: the alias only exists while the
add-on is registered, and Blender does not guarantee add-on registration order.
Look it up lazily instead.

```python
import sys

REQUIRED_API = (1, 0)


def _api():
    """P4Blender's API, or None if unavailable. Never cached — the alias
    disappears when the add-on is disabled."""
    module = sys.modules.get("p4blender")
    if module is None:
        return None
    if getattr(module, "API_VERSION", (0, 0)) < REQUIRED_API:
        return None
    try:
        return module if module.available() else None
    except Exception:
        return None


def checkout(path):
    api = _api()
    if api is None:
        return True          # no Perforce here — proceed
    try:
        return api.checkout(path)
    except Exception:
        return True
```

Decide deliberately what absence means: returning `True` lets people without
Perforce keep working, `False` makes tracked exports mandatory.

There is also an operator form, if you would rather import nothing at all:

```python
if bpy.ops.p4.checkout_file(filepath=path) == {'FINISHED'}:
    ...
```

## Troubleshooting

**`must create client 'YOURHOSTNAME' to access local files`**
`P4CLIENT` is not set anywhere, so `p4` fell back to your machine name. The
message names a workspace that never existed, which reads like an auth failure
but is not. Use **Detect Workspace**, or `p4 set P4CLIENT=<name>` to fix it for
every Perforce tool at once.

**`Path '...' is not under client's root '...'`**
Perforce matches the client root as a literal string, so a `subst`ed drive,
junction or symlink never matches even though it is the same file on disk. The
add-on resolves paths with `realpath` before calling `p4`, which handles all
three — if you still see this, the file genuinely is outside the workspace.

**`Client '...' can only be used from host '...'`**
That workspace is bound to a different machine. Pick one belonging to this one.

**`p4 executable not found on PATH`**
Blender on Windows often inherits Explorer's environment rather than a shell's.
Install location is checked as a fallback; otherwise add `p4` to the system
`PATH`.

## Layout

```
p4/          p4 CLI wrapper and per-file status — no Blender state
handlers/    the save_pre hook
operators/   checkout, submit, diagnostics
ui/          File > Perforce menu, sidebar panel
api.py       public API
preferences.py
constants.py
```
