"""Sidebar panel: current file state, check out, submit.

draw() runs on every redraw, so it never touches Perforce. It reads the state
cached by the last get_status() call - which the save handler makes anyway -
and offers a Refresh for when the file changed underneath you.
"""

import os

import bpy  # type: ignore

from ..constants import AddonProperties, get_operator, get_preferences
from ..p4 import status as p4_status

# how each state reads in the panel: (icon, text)
_PRESENTATION = {
    p4_status.OPEN: ("UNLOCKED", "Checked out"),
    p4_status.NOT_OPEN: ("LOCKED", "Not checked out"),
    p4_status.OTHER_USER: ("ERROR", "Checked out by someone else"),
    p4_status.NOT_IN_DEPOT: ("QUESTION", "Not in the depot"),
    p4_status.ERROR: ("ERROR", "Unavailable"),
}


class VIEW3D_PT_p4_panel(bpy.types.Panel):
    bl_label = "Perforce"
    bl_idname = "VIEW3D_PT_p4_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = AddonProperties.panel_category

    @classmethod
    def poll(cls, context):
        prefs = get_preferences()
        return prefs is not None and prefs.enabled

    def draw(self, context):
        layout = self.layout
        filepath = bpy.data.filepath

        if not filepath:
            layout.label(text="File has never been saved", icon="ERROR")
            return

        box = layout.box()
        box.label(text=os.path.basename(filepath), icon="FILE_BLEND")

        state = p4_status.LAST.get(filepath)
        if state is None:
            box.label(text="State unknown — press Refresh", icon="QUESTION")
        else:
            icon, text = _PRESENTATION.get(state.state, ("QUESTION", "Unknown"))
            box.label(text=text, icon=icon)

            if state.state == p4_status.OPEN and state.fields.get("headRev"):
                box.label(text=f"revision #{state.fields['headRev']}")
            if state.message and state.state == p4_status.ERROR:
                box.label(text=state.message)
            for other in state.other_users:
                box.label(text=f"also open: {other}", icon="USER")

        column = layout.column(align=True)
        column.operator(get_operator("show_status"), text="Refresh", icon="FILE_REFRESH")

        # Offer a checkout unless we already know it is open - the state may be
        # stale or absent, and p4 edit on an open file is harmless anyway.
        if state is None or state.state != p4_status.OPEN:
            column.operator(get_operator("checkout_current"), text="Check Out", icon="UNLOCKED")

        column.separator()
        column.operator(get_operator("submit_file"), text="Submit", icon="EXPORT")
