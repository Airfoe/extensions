"""File > Perforce submenu."""

import bpy  # type: ignore

from ..constants import get_operator, get_preferences


class TOPBAR_MT_p4_menu(bpy.types.Menu):
    bl_idname = "TOPBAR_MT_p4_menu"
    bl_label = "Perforce"

    def draw(self, context):
        layout = self.layout
        layout.operator(get_operator("show_status"), icon="FILE_REFRESH")
        layout.operator(get_operator("checkout_current"), icon="UNLOCKED")
        layout.separator()
        layout.operator(get_operator("submit_file"), icon="EXPORT")


def draw_file_menu_entry(self, context):
    prefs = get_preferences()
    if prefs is None or not prefs.enabled:
        return
    self.layout.separator()
    self.layout.menu(TOPBAR_MT_p4_menu.bl_idname, icon="URL")
