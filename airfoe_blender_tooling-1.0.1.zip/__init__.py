import bpy  # type: ignore
from bpy.props import BoolProperty, PointerProperty

# preferences
from .preferences import Sample_Preferences

# Operators
from .operators.OBJECT_OT_Sample import OBJECT_OT_Sample
from .operators.OBJECT_OT_Export import OBJECT_OT_Export
from .operators.OBJECT_OT_ExportUSD import OBJECT_OT_ExportUSD

# panels
from .panels.VIEW3D_PT_UI_Sample import VIEW3D_PT_UI_Sample


class ExportHookSettings(bpy.types.PropertyGroup):
    enable_export_hook: BoolProperty(
        name="Enable Export Hook",
        description="Toggle whether USD export runs automatically after saving the blend file.",
        default=False,
    )


@bpy.app.handlers.persistent
def export_usd_on_save(dummy):
    if not bpy.data.filepath:
        return

    scene = bpy.context.scene
    if not scene or not getattr(scene, "export_hook_settings", None):
        return

    if not scene.export_hook_settings.enable_export_hook:
        return

    bpy.ops.airfoe.export_usd()


# reading values such as name, version and more from toml so there is no need to change information in two places
def load_manifest_info():
    from .constants import get_manifest

    manifest = get_manifest()

    # reading addon name
    extension_name = manifest["name"]

    # reading addon version
    version_str = manifest["version"]
    version_tuple = tuple(int(x) for x in version_str.split("."))

    # reading Blender version
    blender_version_str = manifest["blender_version_min"]
    blender_version_tuple = tuple(int(x) for x in blender_version_str.split("."))

    bl_info = {
        "name": extension_name,
        "version": version_tuple,
        "blender": blender_version_tuple,
    }

    return bl_info


blender_manifest = load_manifest_info()
bl_info = {
    "name": blender_manifest["name"],
    "description": "Tooling for Airfoe",
    "author": "Fxnarji",
    "version": blender_manifest["version"],
    "blender": blender_manifest["blender"],
    "location": "Npanel",
    "support": "COMMUNITY",
    "category": "UI",
}

classes = [
    # preferences
    Sample_Preferences,
    # property groups:
    ExportHookSettings,
    # operators:
    OBJECT_OT_Sample,
    OBJECT_OT_Export,
    OBJECT_OT_ExportUSD,
    # panels:
    VIEW3D_PT_UI_Sample,
]


def register():
    for i in classes:
        bpy.utils.register_class(i)
    bpy.types.Scene.export_hook_settings = PointerProperty(type=ExportHookSettings)
    if export_usd_on_save not in bpy.app.handlers.save_post:
        bpy.app.handlers.save_post.append(export_usd_on_save)


def unregister():
    if export_usd_on_save in bpy.app.handlers.save_post:
        bpy.app.handlers.save_post.remove(export_usd_on_save)
    if hasattr(bpy.types.Scene, "export_hook_settings"):
        del bpy.types.Scene.export_hook_settings
    for i in reversed(classes):
        bpy.utils.unregister_class(i)


if __name__ == "__main__":
    register()

