"""Public API for other add-ons.

P4Blender's real module name depends on where it was installed from
(``bl_ext.user_default.P4Blender``, ``bl_ext.vscode_development.P4Blender``,
...), so importing it directly is not portable. Two stable entry points are
provided instead, and both work without knowing that name.

Plain Python, if you want return values and no operator overhead::

    import p4blender
    if p4blender.checkout(fbx_path):
        ...

Operators, if you would rather not import anything at all::

    if bpy.ops.p4.checkout_file(filepath=fbx_path) == {'FINISHED'}:
        ...

Guard against the add-on being absent or disabled::

    p4blender = sys.modules.get("p4blender")
    if p4blender is None or not p4blender.available():
        ...

Nothing here raises. Every function reports failure through its return value
and logs the detail to the console, so a Perforce problem can never take down
the calling add-on.
"""

import os

from .constants import get_preferences, log
from .p4 import cli, status as _status

# Contract version, independent of the add-on version. Bumped major on any
# breaking change to the functions below, minor on additions. Consumers can
# check it before calling: getattr(p4blender, "API_VERSION", (0, 0)) >= (1, 0)
API_VERSION = (1, 0)

# state strings returned by status()
OPEN = "open"
NOT_OPEN = "not_open"
OTHER_USER = "other_user"
NOT_IN_DEPOT = "not_in_depot"
NO_FILE = "no_file"
ERROR = "error"

_STATE_MAP = {
    _status.OPEN: OPEN,
    _status.NOT_OPEN: NOT_OPEN,
    _status.OTHER_USER: OTHER_USER,
    _status.NOT_IN_DEPOT: NOT_IN_DEPOT,
    _status.ERROR: ERROR,
}


def available():
    """Whether P4Blender is enabled and can find the p4 client."""
    try:
        prefs = get_preferences()
        if prefs is None or not prefs.enabled:
            return False
        return cli.find_p4_exe() is not None
    except Exception as exception:
        log(f"api.available failed: {exception}")
        return False


def status(filepath):
    """Perforce state of `filepath` as a string.

    One of: "open", "not_open", "other_user", "not_in_depot", "no_file",
    "error".
    """
    if not isinstance(filepath, str) or not filepath:
        return ERROR

    if not os.path.exists(filepath):
        return NO_FILE

    try:
        return _STATE_MAP.get(_status.get_status(filepath).state, ERROR)
    except Exception as exception:
        log(f"api.status failed for {filepath}: {exception}")
        return ERROR


def checkout(filepath):
    """Make `filepath` writable and tracked by Perforce. Returns True on success.

    Handles the three cases an exporter runs into:

    * the file does not exist yet - nothing blocks writing it, so True. Call
      again after writing and it will be opened for add.
    * the file exists but is not in the depot - opened for add.
    * the file exists and is in the depot - opened for edit.

    Already open counts as success. Safe to call on every export.
    """
    if not isinstance(filepath, str) or not filepath:
        log("api.checkout called without a filepath")
        return False

    if not available():
        return False

    # Nothing to do for a file that does not exist yet - and p4 add would
    # fail on it. The caller should call again once it has been written.
    if not os.path.exists(filepath):
        return True

    try:
        state = _status.get_status(filepath)

        if state.state == _status.OPEN:
            return True

        if state.state == _status.NOT_IN_DEPOT:
            success, message = _status.add(filepath)
        elif state.state == _status.ERROR:
            log(f"api.checkout: {state.message or 'status check failed'}")
            return False
        else:
            # NOT_OPEN, or open by someone else - Perforce permits both
            success, message = _status.checkout(filepath)

        if not success:
            log(f"api.checkout failed for {filepath}: {message}")
        return success
    except Exception as exception:
        log(f"api.checkout failed for {filepath}: {exception}")
        return False


def submit(filepath, description):
    """Submit one file. Returns True on success.

    Refuses anything that needs a human decision - unresolved changes, an
    out-of-date revision, a numbered changelist - rather than guessing. The
    reason goes to the console.
    """
    if not isinstance(filepath, str) or not filepath:
        return False
    if not isinstance(description, str) or not description.strip():
        log("api.submit called without a description")
        return False
    if not available():
        return False

    try:
        blocker = _status.submit_blocker(_status.get_status(filepath))
        if blocker:
            log(f"api.submit refused for {filepath}: {blocker}")
            return False

        success, message = _status.submit(filepath, description.strip())
        if not success:
            log(f"api.submit failed for {filepath}: {message}")
        return success
    except Exception as exception:
        log(f"api.submit failed for {filepath}: {exception}")
        return False
