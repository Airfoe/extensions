# i like to put values i need in multiple places here so i can change them in one place
import bpy  # type: ignore
import os
import tomllib


# has to be all lowercase
bl_id_prefix = "p4"

# prefix for every print() this addon makes, so the console is greppable
LOG_PREFIX = "[P4Blender]"

# how long we let a p4 subprocess run before giving up (seconds).
# the status check runs inside save_pre, so it has to stay short.
P4_STATUS_TIMEOUT = 8
P4_EDIT_TIMEOUT = 20
# a submit uploads the whole file, so it gets far more room than the rest
P4_SUBMIT_TIMEOUT = 300


class AddonProperties:
    module_name = __package__
    # sidebar tab the panel lives under
    panel_category = "Perforce"


def get_manifest():
    toml_path = os.path.join(os.path.dirname(__file__), "blender_manifest.toml")
    with open(toml_path, "rb") as f:
        manifest = tomllib.load(f)
    return manifest


def get_preferences():
    # No context needed, directly get addon preferences by package name.
    # Returns None if the addon is mid-unregister, so callers can bail out
    # instead of raising inside a handler.
    addon = bpy.context.preferences.addons.get(__package__)
    if addon is None:
        return None
    return addon.preferences


def get_operator(name):
    return bl_id_prefix + "." + name


def log(message):
    print(f"{LOG_PREFIX} {message}")
