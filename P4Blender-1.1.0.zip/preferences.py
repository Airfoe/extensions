import bpy  # type: ignore

from .constants import get_operator
from .p4 import cli


class P4Blender_Preferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    enabled: bpy.props.BoolProperty(
        name="Check Out On Save",
        description="Check the current .blend out of Perforce when it is saved",
        default=True,
    )

    p4port: bpy.props.StringProperty(
        name="P4PORT",
        description="Server address, e.g. ssl:perforce.example.com:1666. Only used when P4PORT is not already set in the environment",
        default="",
    )
    p4user: bpy.props.StringProperty(
        name="P4USER",
        description="Perforce user name. Only used when P4USER is not already set in the environment",
        default="",
    )
    p4client: bpy.props.StringProperty(
        name="P4CLIENT",
        description="Workspace name. Only used when P4CLIENT is not already set in the environment",
        default="",
    )

    auto_checkout: bpy.props.BoolProperty(
        name="Auto Check Out Read-Only Files",
        description=(
            "Check out without asking when the file is read-only. Perforce keeps "
            "unopened files read-only, so the save fails unless the checkout happens "
            "before Blender writes - and a confirmation dialog cannot be shown that "
            "early. Turn this off to be asked instead, at the cost of the first save "
            "failing"
        ),
        default=True,
    )

    prompt_cooldown: bpy.props.FloatProperty(
        name="Prompt Cooldown",
        description="Seconds to wait before asking about the same file again, so declining a checkout and saving repeatedly doesn't stack up dialogs",
        default=30.0,
        min=0.0,
        max=600.0,
        subtype="TIME_ABSOLUTE",
    )

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "enabled")

        body = layout.column()
        body.enabled = self.enabled

        box = body.box()
        box.label(text="Connection", icon="URL")
        box.label(
            text="Environment values win; these are used only when the variable is unset.",
            icon="INFO",
        )
        box.prop(self, "p4port")
        box.prop(self, "p4user")
        box.prop(self, "p4client")

        box = body.box()
        box.label(text="Behaviour", icon="PREFERENCES")
        box.prop(self, "auto_checkout")
        if not self.auto_checkout:
            box.label(
                text="Saving a read-only file will fail once before you are asked.",
                icon="ERROR",
            )
        # still relevant with auto checkout on: a writable-but-unopened file
        # is resolved by the deferred prompt either way
        box.prop(self, "prompt_cooldown")

        box = body.box()
        box.label(text="Diagnostics", icon="CONSOLE")
        executable = cli.find_p4_exe()
        if executable:
            box.label(text=f"p4: {executable}", icon="CHECKMARK")
        else:
            box.label(text="p4 executable not found on PATH", icon="ERROR")

        # Only what we explicitly pass on the command line. A blank here is
        # not a problem: p4 has its own sources (the Windows registry via
        # `p4 set`, a P4CONFIG file) that we cannot see and must not
        # second-guess - which is what Test Connection is for.
        overrides = {key: value for key, value in cli.resolve_all().items() if value}
        if overrides:
            box.label(text="Passed explicitly to p4:", icon="DOT")
            for key, value in overrides.items():
                box.label(text=f"    {key} = {value}")
        else:
            box.label(text="Nothing overridden; p4 uses its own settings", icon="DOT")

        probe = cli.PROBE
        if probe:
            box.label(text="Reported by p4:", icon="DOT")
            for key in ("P4PORT", "P4USER", "P4CLIENT"):
                value, origin = probe.get(key, ("", ""))
                if value:
                    box.label(text=f"    {key} = {value} {origin}")
                else:
                    box.label(text=f"    {key} unset", icon="ERROR")
            if probe.get("error"):
                box.label(text=f"    {probe['error']}", icon="ERROR")
            else:
                box.label(text="    server reachable", icon="CHECKMARK")

        row = box.row()
        row.operator(get_operator("test_connection"), icon="PLUGIN")
        row.operator(get_operator("show_status"), icon="FILE_REFRESH")
        row.operator(get_operator("checkout_current"), icon="UNLOCKED")
        row.operator(get_operator("detect_workspace"), icon="VIEWZOOM")
