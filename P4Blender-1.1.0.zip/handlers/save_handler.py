"""The save_pre hook.

Rules this file lives by:

1. Nothing in here may raise. An exception escaping save_pre aborts the save
   and the user loses work, so every path is wrapped and the worst case is a
   line in the console.
2. Nothing in here blocks on a dialog. save_pre runs *during* the save, so a
   modal popup would freeze it - the prompt goes to a timer that fires once
   the save is done.

That second rule collides with how Perforce works: an unopened file is
read-only on disk, so deferring the checkout means the save it was meant to
protect fails with "path is not writable". Dialogs are impossible this early,
so read-only files are checked out inline instead (fast, no UI) and only the
writable-but-unopened case - where the save succeeds regardless - gets the
deferred prompt. See _handle_not_open().
"""

import os
import time

import bpy  # type: ignore
from bpy.app.handlers import persistent  # type: ignore

from ..constants import get_operator, get_preferences, log
from ..p4 import status as p4_status

# filepath -> monotonic timestamp of the last prompt, so declining a checkout
# and then hammering Ctrl+S doesn't produce a stack of dialogs
_last_prompt = {}


def _popup(title, message, icon="ERROR"):
    """Show a message from outside an operator, on the next timer tick.

    popup_menu straight from save_pre is not reliable - the window manager is
    busy with the save - so it goes through the same deferral as the prompt.
    """

    def show():
        try:
            bpy.context.window_manager.popup_menu(
                lambda menu, context: menu.layout.label(text=message),
                title=title,
                icon=icon,
            )
        except Exception as exception:
            log(f"could not show popup: {exception}")
        return None

    try:
        bpy.app.timers.register(show, first_interval=0.05)
    except Exception as exception:
        log(f"could not schedule popup: {exception}")


def _stage_checkout(filepath, resave):
    """Queue the confirm dialog for after the save finishes."""

    category, name = get_operator("checkout_confirm").split(".")

    def prompt():
        try:
            getattr(getattr(bpy.ops, category), name)(
                "INVOKE_DEFAULT",
                filepath=filepath,
                resave=resave,
            )
        except Exception as exception:
            log(f"could not open checkout prompt: {exception}")
        return None

    try:
        bpy.app.timers.register(prompt, first_interval=0.05)
    except Exception as exception:
        log(f"could not schedule checkout prompt: {exception}")


def _should_prompt(filepath, cooldown):
    now = time.monotonic()
    previous = _last_prompt.get(filepath)
    if previous is not None and (now - previous) < cooldown:
        log(f"skipping prompt for {os.path.basename(filepath)} (cooldown)")
        return False
    _last_prompt[filepath] = now
    return True


def _checkout_inline(filepath):
    """Check out right now, inside the handler, before Blender writes.

    Used only when the file is read-only, because then the save is going to
    fail outright unless Perforce clears the flag first - and a confirmation
    dialog is impossible at this point in the save. Blocking for the length
    of one `p4 edit` beats losing the save.
    """
    success, message = p4_status.checkout(filepath)
    name = os.path.basename(filepath)

    if success:
        log(f"auto checked out {filepath} ({message})")
        _popup("Perforce", f"Checked out {name}", icon="CHECKMARK")
        return

    # The save is about to fail on its own; make sure the reason is visible
    # rather than leaving the user with Blender's bare "not writable".
    log(f"auto checkout failed for {filepath}: {message}")
    _popup("Perforce", f"Checkout failed, save will fail - {message}")


def _handle_not_open(filepath, writable, prefs):
    """Decide how to resolve a file that isn't open for edit.

    The read-only case has to be settled before the write or the save dies,
    so it gets a silent inline checkout. A writable file can wait: the save
    will succeed either way, so we defer and actually ask.
    """
    if not writable:
        if prefs.auto_checkout:
            _checkout_inline(filepath)
            return
        # User opted out of silent checkouts, so the save is going to fail.
        # Prompt afterwards and offer to write the file again.
        if _should_prompt(filepath, prefs.prompt_cooldown):
            _stage_checkout(filepath, resave=True)
        return

    if _should_prompt(filepath, prefs.prompt_cooldown):
        _stage_checkout(filepath, resave=False)


def _save_pre_impl():
    prefs = get_preferences()
    if prefs is None:
        return
    if not prefs.enabled:
        return

    filepath = bpy.data.filepath
    if not filepath:
        # Never-saved file, or Save As to a new path: there is nothing for
        # Perforce to open for edit yet.
        return

    # Perforce leaves unopened files read-only, so this flag is what decides
    # whether the save is doomed and the checkout has to happen inline.
    writable = p4_status.is_writable(filepath)

    result = p4_status.get_status(filepath)

    if result.state == p4_status.OPEN:
        return

    if result.state == p4_status.OTHER_USER:
        others = ", ".join(result.other_users)
        log(f"{filepath} is open by {others}")
        _popup("Perforce", f"Also checked out by {others}")
        # Perforce allows concurrent checkouts by default, so this is a
        # warning rather than a stop - resolve it like any other unopened file
        _handle_not_open(filepath, writable, prefs)
        return

    if result.state == p4_status.NOT_IN_DEPOT:
        log(f"{filepath} is not in the depot - nothing to check out")
        _popup("Perforce", "File is not in the depot", icon="INFO")
        return

    if result.state == p4_status.ERROR:
        _popup("Perforce", result.message or "status check failed")
        return

    # NOT_OPEN: the case this addon exists for.
    _handle_not_open(filepath, writable, prefs)


@persistent
def p4_save_pre(_dummy):
    """@persistent so it survives loading a .blend - handlers are otherwise
    cleared on file load and the hook would silently stop working."""
    try:
        _save_pre_impl()
    except Exception as exception:
        # The whole point: a Perforce problem must never cost the user a save.
        log(f"save_pre failed, letting the save continue: {exception}")
        _popup("Perforce", f"Add-on error: {exception}")


@persistent
def p4_load_post(_dummy):
    """Forget per-file state when a different file is opened."""
    try:
        _last_prompt.clear()
        # stale cache would show the previous file's state in the sidebar
        p4_status.LAST.clear()
    except Exception:
        pass


def register_handlers():
    if p4_save_pre not in bpy.app.handlers.save_pre:
        bpy.app.handlers.save_pre.append(p4_save_pre)
    if p4_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(p4_load_post)


def unregister_handlers():
    # compare by name as well: reloading the addon leaves a stale function
    # object registered that is no longer identical to ours
    for handler_list, function in (
        (bpy.app.handlers.save_pre, p4_save_pre),
        (bpy.app.handlers.load_post, p4_load_post),
    ):
        for existing in list(handler_list):
            if existing is function or getattr(existing, "__name__", None) == function.__name__:
                handler_list.remove(existing)
