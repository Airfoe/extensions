"""Operators that actually talk to Perforce.

The save handler never checks anything out itself - it stages a request and
one of these runs afterwards, so the dialog is never in the save's way.
"""

import os

import bpy  # type: ignore

from ..constants import get_operator, get_preferences, log
from ..p4 import cli as p4_cli
from ..p4 import status as p4_status


def _report_status(operator, filepath, success, message):
    """Single place where a checkout outcome becomes user-visible."""
    name = os.path.basename(filepath) or filepath
    if success:
        operator.report({"INFO"}, f"P4: checked out {name}")
        log(f"checked out {filepath} ({message})")
    else:
        operator.report({"WARNING"}, f"P4: could not check out {name} - {message}")
        log(f"checkout failed for {filepath}: {message}")


def _resave(operator, filepath):
    """Write the file again now that it is writable.

    Only meaningful when the save that triggered us bounced off a read-only
    file. Re-entering save_mainfile runs save_pre again, but by then the file
    is open for edit so the handler is a no-op - no recursion.
    """
    if not p4_status.is_writable(filepath):
        operator.report({"WARNING"}, "P4: file is still read-only, save again manually")
        return

    try:
        bpy.ops.wm.save_mainfile()
        operator.report({"INFO"}, "P4: file saved after checkout")
    except RuntimeError as exception:
        operator.report({"WARNING"}, f"P4: re-save failed - {exception}")
        log(f"re-save failed: {exception}")


class P4_OT_CheckoutConfirm(bpy.types.Operator):
    """Ask before opening the current file for edit in Perforce"""

    bl_idname = get_operator("checkout_confirm")
    bl_label = "Check Out From Perforce"
    bl_options = {"REGISTER", "INTERNAL"}

    filepath: bpy.props.StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    resave: bpy.props.BoolProperty(default=False, options={"HIDDEN", "SKIP_SAVE"})

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(
            self,
            event,
            title="Perforce",
            message="This file isn't checked out — check out now?",
            confirm_text="Check Out",
        )

    def execute(self, context):
        filepath = self.filepath or bpy.data.filepath
        if not filepath:
            self.report({"WARNING"}, "P4: no file on disk to check out")
            return {"CANCELLED"}

        try:
            success, message = p4_status.checkout(filepath)
        except Exception as exception:  # defensive - p4 layer shouldn't raise
            self.report({"WARNING"}, f"P4: checkout failed - {exception}")
            log(f"unexpected checkout error: {exception}")
            return {"CANCELLED"}

        _report_status(self, filepath, success, message)

        if not success:
            return {"CANCELLED"}

        if self.resave:
            _resave(self, filepath)

        return {"FINISHED"}


class P4_OT_CheckoutCurrent(bpy.types.Operator):
    """Open the current .blend for edit in Perforce, without asking"""

    bl_idname = get_operator("checkout_current")
    bl_label = "Check Out Current File"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return bool(bpy.data.filepath)

    def execute(self, context):
        filepath = bpy.data.filepath
        try:
            success, message = p4_status.checkout(filepath)
        except Exception as exception:
            self.report({"WARNING"}, f"P4: checkout failed - {exception}")
            return {"CANCELLED"}

        _report_status(self, filepath, success, message)
        return {"FINISHED"} if success else {"CANCELLED"}


class P4_OT_CheckoutFile(bpy.types.Operator):
    """Check out an arbitrary file - the operator half of the public API

    Other add-ons can call this without importing P4Blender, whose module name
    depends on how it was installed:

        bpy.ops.p4.checkout_file(filepath=path) == {'FINISHED'}
    """

    bl_idname = get_operator("checkout_file")
    bl_label = "Check Out File"
    bl_options = {"REGISTER"}

    filepath: bpy.props.StringProperty(subtype="FILE_PATH")
    quiet: bpy.props.BoolProperty(
        name="Quiet",
        description="Log failures instead of reporting them in the interface",
        default=False,
    )

    def execute(self, context):
        from .. import api

        if not self.filepath:
            self.report({"WARNING"}, "P4: no filepath given")
            return {"CANCELLED"}

        if api.checkout(self.filepath):
            return {"FINISHED"}

        if not self.quiet:
            self.report(
                {"WARNING"},
                f"P4: could not check out {os.path.basename(self.filepath)} (see console)",
            )
        return {"CANCELLED"}


class P4_OT_TestConnection(bpy.types.Operator):
    """Ask p4 what it will actually use, and whether the server answers"""

    bl_idname = get_operator("test_connection")
    bl_label = "Test Connection"
    bl_options = {"REGISTER"}

    def execute(self, context):
        try:
            settings, error = p4_cli.effective_settings()
        except Exception as exception:
            self.report({"WARNING"}, f"P4: {exception}")
            return {"CANCELLED"}

        if error:
            p4_cli.PROBE = {"error": error}
            self.report({"WARNING"}, f"P4: {error}")
            return {"CANCELLED"}

        probe = {key: settings.get(key, ("", "")) for key in ("P4PORT", "P4USER", "P4CLIENT")}

        # `p4 set` is answered locally, so it proves nothing about the server.
        info = p4_cli.run(["info"], timeout=8)
        probe["error"] = info.error
        p4_cli.PROBE = probe

        if info.error:
            self.report({"WARNING"}, f"P4: {info.error}")
            return {"CANCELLED"}

        self.report({"INFO"}, "P4: connection OK")
        return {"FINISHED"}


class P4_OT_DetectWorkspace(bpy.types.Operator):
    """Find the workspace that maps the current .blend and store it in the preferences"""

    bl_idname = get_operator("detect_workspace")
    bl_label = "Detect Workspace"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return bool(bpy.data.filepath)

    def execute(self, context):
        prefs = get_preferences()
        if prefs is None:
            self.report({"WARNING"}, "P4: preferences unavailable")
            return {"CANCELLED"}

        try:
            name, message = p4_status.detect_client(bpy.data.filepath)
        except Exception as exception:
            self.report({"WARNING"}, f"P4: detection failed - {exception}")
            return {"CANCELLED"}

        if not name:
            self.report({"WARNING"}, f"P4: {message}")
            return {"CANCELLED"}

        prefs.p4client = name
        # preferences are only written to disk on demand when auto-save is off
        try:
            bpy.ops.wm.save_userpref()
        except RuntimeError as exception:
            log(f"could not persist preferences: {exception}")

        self.report({"INFO"}, f"P4: using workspace {name}")
        return {"FINISHED"}


class P4_OT_ShowStatus(bpy.types.Operator):
    """Report what Perforce thinks of the current .blend"""

    bl_idname = get_operator("show_status")
    bl_label = "Show Perforce Status"
    bl_options = {"REGISTER"}

    def execute(self, context):
        filepath = bpy.data.filepath
        if not filepath:
            self.report({"WARNING"}, "P4: file has never been saved")
            return {"CANCELLED"}

        prefs = get_preferences()
        if prefs is not None and not prefs.enabled:
            self.report({"INFO"}, "P4: addon is disabled in preferences")
            return {"CANCELLED"}

        try:
            result = p4_status.get_status(filepath)
        except Exception as exception:
            self.report({"WARNING"}, f"P4: status check failed - {exception}")
            return {"CANCELLED"}

        if result.state == p4_status.OPEN:
            self.report({"INFO"}, f"P4: checked out ({result.message})")
        elif result.state == p4_status.NOT_OPEN:
            self.report({"WARNING"}, "P4: not checked out")
        elif result.state == p4_status.OTHER_USER:
            self.report({"WARNING"}, f"P4: checked out by {', '.join(result.other_users)}")
        elif result.state == p4_status.NOT_IN_DEPOT:
            self.report({"WARNING"}, "P4: file is not in the depot")
        else:
            self.report({"WARNING"}, f"P4: {result.message}")

        return {"FINISHED"}
