"""Reverting the current .blend.

Two separate things get discarded here and the operator has to be explicit
about both:

* Perforce throws away the local file's changes since checkout, and restores
  the depot revision on disk.
* Blender is still holding the modified scene in memory. Left alone, the next
  save would write those changes straight back out, quietly undoing the
  revert - so the file is reloaded from disk afterwards.

Neither is undoable, which is why this always confirms first.
"""

import os

import bpy  # type: ignore

from ..constants import get_operator, log
from ..p4 import status as p4_status


class P4_OT_RevertFile(bpy.types.Operator):
    """Discard local changes and restore the depot revision"""

    bl_idname = get_operator("revert_file")
    bl_label = "Revert File"
    bl_options = {"REGISTER"}

    reload_file: bpy.props.BoolProperty(
        name="Reload File After Reverting",
        description=(
            "Load the restored file back into Blender. Without this the scene in "
            "memory still holds the changes you just discarded, and saving would "
            "write them out again"
        ),
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return bool(bpy.data.filepath)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=440)

    def draw(self, context):
        layout = self.layout
        layout.label(text=os.path.basename(bpy.data.filepath), icon="FILE_BLEND")

        box = layout.box()
        box.label(text="This discards every change since checkout.", icon="ERROR")
        box.label(text="It cannot be undone.")

        layout.prop(self, "reload_file")
        if not self.reload_file:
            layout.label(
                text="Scene in memory will still hold the discarded changes.",
                icon="ERROR",
            )

    def execute(self, context):
        filepath = bpy.data.filepath
        if not filepath:
            self.report({"WARNING"}, "P4: file has never been saved")
            return {"CANCELLED"}

        try:
            state = p4_status.get_status(filepath)
        except Exception as exception:
            self.report({"WARNING"}, f"P4: status check failed - {exception}")
            return {"CANCELLED"}

        if state.state != p4_status.OPEN:
            self.report({"WARNING"}, "P4: file is not checked out, nothing to revert")
            return {"CANCELLED"}

        try:
            success, message = p4_status.revert(filepath)
        except Exception as exception:
            self.report({"WARNING"}, f"P4: revert failed - {exception}")
            return {"CANCELLED"}

        if not success:
            self.report({"WARNING"}, f"P4: revert failed - {message}")
            log(f"revert failed for {filepath}: {message}")
            return {"CANCELLED"}

        log(f"reverted {filepath}: {message}")

        if self.reload_file:
            # Reverting an open-for-add leaves the file on disk but untracked;
            # reverting an edit restores the depot revision. Either way what is
            # on disk is now the truth, so load it.
            if not os.path.exists(filepath):
                self.report({"WARNING"}, "P4: reverted, but the file is no longer on disk")
                return {"FINISHED"}
            try:
                bpy.ops.wm.revert_mainfile()
            except RuntimeError as exception:
                self.report({"WARNING"}, f"P4: reverted, but reload failed - {exception}")
                log(f"reload after revert failed: {exception}")
                return {"FINISHED"}

        self.report({"INFO"}, f"P4: {message}")
        return {"FINISHED"}
