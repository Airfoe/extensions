"""Submitting the current .blend.

Scope is deliberately narrow: one file, from the default changelist, up to
date, opened by us. Everything else - unresolved changes, a numbered
changelist, someone else's newer revision - is reported and refused rather
than guessed at, because every one of those cases can end with a binary file
where somebody's work quietly disappears.
"""

import os

import bpy  # type: ignore

from ..constants import get_operator, log
from ..p4 import status as p4_status


class P4_OT_SubmitFile(bpy.types.Operator):
    """Submit the current .blend to Perforce"""

    bl_idname = get_operator("submit_file")
    bl_label = "Submit To Perforce"
    bl_options = {"REGISTER"}

    description_text: bpy.props.StringProperty(
        name="Description",
        description="Changelist description. Perforce requires a non-empty one",
        default="",
    )
    save_first: bpy.props.BoolProperty(
        name="Save Before Submitting",
        description="Write unsaved changes first, so the submitted revision matches what you see",
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return bool(bpy.data.filepath)

    def invoke(self, context, event):
        self.description_text = ""
        return context.window_manager.invoke_props_dialog(self, width=420)

    def draw(self, context):
        layout = self.layout
        layout.label(text=os.path.basename(bpy.data.filepath), icon="FILE_BLEND")
        layout.prop(self, "description_text")
        layout.prop(self, "save_first")
        if bpy.data.is_dirty and not self.save_first:
            layout.label(text="Unsaved changes will not be included.", icon="ERROR")

    def execute(self, context):
        filepath = bpy.data.filepath
        if not filepath:
            self.report({"WARNING"}, "P4: file has never been saved")
            return {"CANCELLED"}

        description = self.description_text.strip()
        if not description:
            self.report({"WARNING"}, "P4: a description is required")
            return {"CANCELLED"}

        if self.save_first and bpy.data.is_dirty:
            try:
                bpy.ops.wm.save_mainfile()
            except RuntimeError as exception:
                self.report({"WARNING"}, f"P4: could not save before submit - {exception}")
                return {"CANCELLED"}

        try:
            state = p4_status.get_status(filepath)
            blocker = p4_status.submit_blocker(state)
        except Exception as exception:
            self.report({"WARNING"}, f"P4: status check failed - {exception}")
            return {"CANCELLED"}

        if blocker:
            self.report({"WARNING"}, f"P4: not submitting - {blocker}")
            log(f"submit refused for {filepath}: {blocker}")
            return {"CANCELLED"}

        try:
            success, message = p4_status.submit(filepath, description)
        except Exception as exception:
            self.report({"WARNING"}, f"P4: submit failed - {exception}")
            return {"CANCELLED"}

        if not success:
            self.report({"WARNING"}, f"P4: submit failed - {message}")
            log(f"submit failed for {filepath}: {message}")
            return {"CANCELLED"}

        self.report({"INFO"}, f"P4: {message}")
        log(f"submitted {filepath}: {message}")
        return {"FINISHED"}
