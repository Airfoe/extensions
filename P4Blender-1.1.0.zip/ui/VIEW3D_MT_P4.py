"""Perforce menu in the 3D View header, alongside View / Select / Add / Object."""

import bpy  # type: ignore

from ..constants import get_operator, get_preferences


class VIEW3D_MT_p4_menu(bpy.types.Menu):
    bl_idname = "VIEW3D_MT_p4_menu"
    bl_label = "Perforce"

    def draw(self, context):
        layout = self.layout
        layout.operator(get_operator("show_status"), icon="FILE_REFRESH")
        layout.operator(get_operator("checkout_current"), icon="UNLOCKED")
        layout.separator()
        layout.operator(get_operator("submit_file"), icon="EXPORT")
        layout.operator(get_operator("revert_file"), icon="LOOP_BACK")


def draw_editor_menus_entry(self, context):
    """Appended to VIEW3D_MT_editor_menus, so it sits after Object/Mesh/etc.

    Returning early when disabled removes the menu from the header entirely
    rather than leaving a dead entry.
    """
    prefs = get_preferences()
    if prefs is None or not prefs.enabled:
        return
    self.layout.menu(VIEW3D_MT_p4_menu.bl_idname)
