"""Reading and changing the Perforce state of a single local file."""

import os

from ..constants import P4_EDIT_TIMEOUT, P4_STATUS_TIMEOUT, P4_SUBMIT_TIMEOUT
from . import cli

# what fstat told us about the file
OPEN = "OPEN"                # already open for edit by us - nothing to do
NOT_OPEN = "NOT_OPEN"        # in the depot, not opened - the interesting case
OTHER_USER = "OTHER_USER"    # someone else has it open
NOT_IN_DEPOT = "NOT_IN_DEPOT"
ERROR = "ERROR"


class FileStatus:
    def __init__(self, state, other_users=None, message=None, fields=None):
        self.state = state
        self.other_users = other_users or []
        self.message = message
        # raw fstat fields, so callers that need more than the state (submit
        # checking revisions, for instance) don't have to run fstat again
        self.fields = fields or {}

    @property
    def needs_checkout(self):
        return self.state == NOT_OPEN

    def __repr__(self):
        return f"<FileStatus {self.state} message={self.message!r}>"


def local_path(filepath):
    """The path Perforce will recognise.

    Perforce matches a file against the client Root as a literal string, so a
    virtual drive (subst), junction or symlink never matches - `X:\\PROD\\...`
    is not under `C:\\Users\\...\\Perforce\\ws`, even though they are the same
    bytes on disk. realpath() resolves all three on Windows, so we hand p4 the
    physical path and keep the original for Blender and for display.
    """
    try:
        return os.path.realpath(filepath)
    except OSError:
        return filepath


def p4_target(filepath):
    """(path to pass to p4, cwd to run it from) for a local file."""
    resolved = local_path(filepath)
    directory = os.path.dirname(resolved) or None
    if directory and not os.path.isdir(directory):
        directory = None
    return escape_path(resolved), directory


def escape_path(filepath):
    """Percent-encode the characters Perforce treats as wildcards.

    A path containing @ # % or * would otherwise be read as a revision
    specifier or a wildcard. % has to be encoded first or we'd double
    encode the escapes we just inserted.
    """
    escaped = filepath.replace("%", "%25")
    escaped = escaped.replace("@", "%40")
    escaped = escaped.replace("#", "%23")
    escaped = escaped.replace("*", "%2A")
    return escaped


def parse_fstat(stdout):
    """Turn `... field value` lines into a dict of field -> value."""
    fields = {}
    for line in stdout.splitlines():
        line = line.strip()
        if not line.startswith("... "):
            continue
        body = line[4:]
        key, _, value = body.partition(" ")
        fields[key] = value.strip()
    return fields


# Last known state per file. Panels redraw constantly and must never shell
# out, so the UI reads this instead of asking Perforce. Filled in by every
# get_status() call - including the one the save handler already makes, which
# keeps it fresh without any extra p4 traffic.
LAST = {}


def get_status(filepath):
    """Ask Perforce about `filepath` and remember the answer. Never raises."""
    state = _query_status(filepath)
    LAST[filepath] = state
    return state


def _query_status(filepath):
    """Ask Perforce about `filepath`. Never raises.

    cwd is the file's own directory so that a P4CONFIG file sitting in the
    workspace is picked up even when Blender was launched from elsewhere.
    """
    target, directory = p4_target(filepath)

    result = cli.run(
        ["fstat", target],
        cwd=directory,
        timeout=P4_STATUS_TIMEOUT,
    )

    if result.error:
        if result.error == "file is not in the depot":
            return FileStatus(NOT_IN_DEPOT, message=result.error)
        return FileStatus(ERROR, message=result.error)

    fields = parse_fstat(result.stdout)

    others = [value for key, value in fields.items() if key.startswith("otherOpen") and "@" in value]

    # `action` is only present when *we* have the file open.
    if fields.get("action"):
        return FileStatus(
            OPEN,
            other_users=others,
            message=f"open for {fields['action']}",
            fields=fields,
        )

    # otherOpen0, otherOpen1, ... each name a user@workspace.
    if others:
        return FileStatus(OTHER_USER, other_users=others, fields=fields)

    if not fields:
        # fstat exited 0 but told us nothing - treat as unknown rather than
        # claiming the file needs a checkout.
        return FileStatus(ERROR, message="p4 fstat returned no information")

    return FileStatus(NOT_OPEN, fields=fields)


def detect_client(filepath):
    """Find which of the user's workspaces contains `filepath`.

    Perforce matches the client Root (and AltRoots) against the literal path,
    so a virtual/mapped drive only resolves if the client spec lists it. Rather
    than parsing specs and guessing, ask the server directly: `p4 -c NAME where`
    succeeds only for the client that actually maps the path.

    Returns (client_name_or_None, message).
    """
    user = cli.resolve_setting("P4USER", "p4user")
    if not user:
        return None, "no P4USER set - fill it in first"

    listing = cli.run(["clients", "-u", user], timeout=P4_STATUS_TIMEOUT)
    if listing.error:
        return None, listing.error

    names = []
    for line in listing.stdout.splitlines():
        parts = line.split()
        if len(parts) >= 2 and parts[0] == "Client":
            names.append(parts[1])

    if not names:
        return None, f"no workspaces found for user {user}"

    target, directory = p4_target(filepath)

    for name in names:
        probe = cli.run(
            ["where", target],
            cwd=directory,
            timeout=P4_STATUS_TIMEOUT,
            client_override=name,
        )
        if probe.ok and probe.stdout.strip():
            return name, f"matched workspace {name}"

    return None, f"none of {len(names)} workspaces map {filepath}"


def checkout(filepath):
    """Run `p4 edit`. Returns (success, message). Never raises."""
    target, directory = p4_target(filepath)

    result = cli.run(
        ["edit", target],
        cwd=directory,
        timeout=P4_EDIT_TIMEOUT,
    )

    if result.error:
        return False, result.error

    message = result.stdout.strip().splitlines()
    return True, message[-1] if message else "opened for edit"


def add(filepath):
    """Run `p4 add`, for a file that exists on disk but not in the depot."""
    target, directory = p4_target(filepath)

    result = cli.run(["add", target], cwd=directory, timeout=P4_EDIT_TIMEOUT)
    if result.error:
        return False, result.error

    lines = result.stdout.strip().splitlines()
    return True, lines[-1] if lines else "opened for add"


def revert(filepath):
    """Run `p4 revert`. Returns (success, message).

    Throws away every local change since the checkout, irreversibly - there is
    no Perforce-side undo. Callers must confirm with the user first.
    """
    target, directory = p4_target(filepath)

    result = cli.run(["revert", target], cwd=directory, timeout=P4_EDIT_TIMEOUT)
    if result.error:
        return False, result.error

    lines = result.stdout.strip().splitlines()
    return True, lines[-1] if lines else "reverted"


def submit_blocker(state):
    """Why this file must not be submitted automatically, or None.

    Deliberately conservative. Anything beyond 'my checkout, up to date, in
    the default changelist' is a situation where guessing could destroy
    someone's work - so we refuse and let the user drive P4V.
    """
    if state.state == NOT_IN_DEPOT:
        return "file is not in the depot"
    if state.state == ERROR:
        return state.message or "could not read file status"
    if state.state != OPEN:
        return "file is not checked out, so there is nothing to submit"

    fields = state.fields

    # A numbered changelist usually means the file is part of a larger,
    # deliberately grouped submit. Don't pull it out from under the user.
    change = fields.get("change", "default")
    if change != "default":
        return f"file is in pending changelist {change} - submit that from P4V"

    if fields.get("unresolved"):
        return "file has unresolved changes - resolve it in P4V first"

    # Submitting an out-of-date binary means someone must choose whose work
    # survives. That is not a decision an addon should make silently.
    have = fields.get("haveRev")
    head = fields.get("headRev")
    if have and head and have != head:
        return (
            f"file is out of date (you have #{have}, latest is #{head}) - "
            f"sync and resolve in P4V first"
        )

    action = fields.get("action")
    if action not in ("edit", "add"):
        return f"file is open for '{action}', which this addon does not submit"

    return None


def submit(filepath, description):
    """Submit just this one file. Returns (success, message).

    Scoped to the file on purpose: a bare `p4 submit` would take the whole
    default changelist, including unrelated work.
    """
    target, directory = p4_target(filepath)

    result = cli.run(
        ["submit", "-d", description, target],
        cwd=directory,
        timeout=P4_SUBMIT_TIMEOUT,
    )

    if result.error:
        return False, result.error

    if "no files to submit" in result.stdout.lower():
        return False, "no changes to submit"

    for line in reversed(result.stdout.strip().splitlines()):
        if "submitted" in line.lower():
            return True, line.strip()
    return True, "submitted"


def is_writable(filepath):
    """Whether we can actually write the file right now.

    Perforce leaves unopened files read-only, so this is the practical test
    for 'did the checkout achieve anything'.
    """
    return os.access(filepath, os.W_OK)
