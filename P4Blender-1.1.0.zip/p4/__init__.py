"""Thin wrapper around the `p4` command line client.

Deliberately has no Blender-side state: everything here takes plain strings
and returns plain data, so it can be unit tested or poked at from the console.
"""
