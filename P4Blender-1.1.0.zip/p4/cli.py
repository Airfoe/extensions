"""Locating and invoking the p4 executable."""

import os
import re
import shutil
import subprocess

from ..constants import P4_STATUS_TIMEOUT, get_preferences, log


class P4Result:
    """Outcome of one p4 invocation.

    `ok` only means the process ran and exited 0 - it says nothing about
    whether the file is checked out. Callers interpret stdout themselves.
    """

    def __init__(self, ok, stdout="", stderr="", error=None):
        self.ok = ok
        self.stdout = stdout
        self.stderr = stderr
        # human readable, already classified - see classify_error()
        self.error = error

    def __repr__(self):
        return f"<P4Result ok={self.ok} error={self.error!r}>"


def find_p4_exe():
    """Return the path to the p4 binary, or None.

    Blender's PATH is whatever launched it, which on Windows is often the
    Explorer environment rather than a shell, so check the usual install
    locations too.
    """
    found = shutil.which("p4")
    if found:
        return found

    candidates = [
        r"C:\Program Files\Perforce\p4.exe",
        r"C:\Program Files (x86)\Perforce\p4.exe",
        "/usr/local/bin/p4",
        "/usr/bin/p4",
        "/opt/homebrew/bin/p4",
    ]
    for path in candidates:
        if os.path.isfile(path):
            return path
    return None


def resolve_setting(env_key, pref_attr):
    """One Perforce setting, environment first then addon preferences."""
    value = os.environ.get(env_key)
    if value:
        return value.strip()
    prefs = get_preferences()
    if prefs is not None:
        return getattr(prefs, pref_attr, "").strip()
    return ""


def resolve_all():
    """The three settings we manage, for display and diagnostics."""
    return {
        "P4PORT": resolve_setting("P4PORT", "p4port"),
        "P4USER": resolve_setting("P4USER", "p4user"),
        "P4CLIENT": resolve_setting("P4CLIENT", "p4client"),
    }


# Filled in by the Test Connection operator. draw() must never shell out - it
# runs on every redraw - so the effective settings are probed on demand and
# cached here.
PROBE = {}


def effective_settings():
    """What p4 itself will use, from every source it knows about.

    resolve_all() only sees the environment and our preferences. On Windows p4
    also reads HKCU\\Software\\Perforce\\Environment (written by `p4 set`), and
    anywhere it reads a P4CONFIG file - both invisible to us, and both perfectly
    valid. Asking `p4 set` is the only honest way to report the real values.
    """
    result = run(["set"], timeout=P4_STATUS_TIMEOUT)
    if result.error:
        return {}, result.error

    settings = {}
    for line in result.stdout.splitlines():
        key, separator, rest = line.partition("=")
        if not separator:
            continue
        # values arrive as "VALUE (set)" / "VALUE (config 'path')"
        value = rest.split(" (")[0].strip()
        origin = rest[len(value):].strip()
        settings[key.strip()] = (value, origin)
    return settings, None


def connection_args(client_override=None):
    """Resolve P4PORT/P4USER/P4CLIENT env-first, prefs fallback.

    A subprocess spawned from Blender may not inherit the shell's Perforce
    configuration, so we pass -p/-u/-c explicitly whenever we have a value
    from either source. Anything we can't resolve is simply omitted and p4
    falls back to its own P4CONFIG lookup (see run(), which sets cwd to the
    .blend's directory precisely so that lookup can succeed).
    """
    args = []
    port = resolve_setting("P4PORT", "p4port")
    user = resolve_setting("P4USER", "p4user")
    client = client_override or resolve_setting("P4CLIENT", "p4client")

    if port:
        args += ["-p", port]
    if user:
        args += ["-u", user]
    if client:
        args += ["-c", client]
    return args


def classify_error(returncode, stdout, stderr):
    """Turn p4's messages into something worth showing a user.

    p4 reports most failures on stderr but some on stdout, and it exits 0 for
    a few of them, so both streams get scanned.
    """
    raw = f"{stdout}\n{stderr}"
    blob = raw.lower()

    if "connect to server failed" in blob or "tcp connect to" in blob:
        return "cannot reach the Perforce server (check P4PORT / VPN)"
    if "password (p4passwd) invalid or unset" in blob or "session has expired" in blob:
        return "not logged in to Perforce (run `p4 login`)"
    if "is not under client's root" in blob or "not in client view" in blob:
        return "file is outside your Perforce workspace"
    # A workspace bound to a different machine - usually a stale client left
    # over from an older PC, picked because P4CLIENT names the wrong one.
    match = re.search(r"can only be used from host '([^']+)'", raw)
    if match:
        return f"that workspace is locked to host '{match.group(1)}', not this machine"
    if "no such file" in blob:
        return "file is not in the depot"
    # When P4CLIENT is unset, p4 silently falls back to the machine's hostname
    # and then complains that "workspace" does not exist. The message names the
    # hostname, which reads as a real workspace and sends people hunting in the
    # wrong direction - so say what actually happened.
    match = re.search(r"must create client '([^']+)' to access local files", raw)
    if match:
        return (
            f"no workspace set - P4CLIENT is unset so p4 fell back to the "
            f"hostname '{match.group(1)}'"
        )
    # "Client 'name' unknown - use 'client' command to create it."
    if "unknown - use 'client' command" in blob:
        return "unknown Perforce workspace (check P4CLIENT)"
    if "file(s) not opened on this client" in blob:
        return "file is not open on this workspace"
    if "must resolve" in blob or "must be resolved" in blob:
        return "file must be resolved before it can be submitted"
    if "out of date" in blob or "file(s) not up-to-date" in blob:
        return "file is out of date - sync and resolve before submitting"
    if "exclusive file already opened" in blob:
        return "another user holds an exclusive lock on this file"
    if "no permission for operation" in blob:
        return "you do not have permission for that operation on this path"

    if returncode != 0:
        message = stderr.strip() or stdout.strip()
        return message.splitlines()[0] if message else f"p4 exited {returncode}"
    return None


def run(args, cwd=None, timeout=15, client_override=None):
    """Run p4 with the given arguments. Never raises.

    Every failure mode - missing binary, timeout, OS error, nonzero exit -
    comes back as a P4Result with `error` set, because the callers of this
    sit underneath a save handler where an exception is unacceptable.
    """
    exe = find_p4_exe()
    if exe is None:
        return P4Result(False, error="p4 executable not found on PATH")

    cmd = [exe] + connection_args(client_override) + list(args)

    try:
        completed = subprocess.run(
            cmd,
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=timeout,
            # keep a console window from flashing up on Windows
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except subprocess.TimeoutExpired:
        return P4Result(False, error=f"p4 {args[0]} timed out after {timeout}s")
    except OSError as exception:
        return P4Result(False, error=f"could not launch p4: {exception}")

    stdout = completed.stdout or ""
    stderr = completed.stderr or ""
    error = classify_error(completed.returncode, stdout, stderr)

    if error:
        log(f"p4 {' '.join(args)} -> {error}")

    return P4Result(completed.returncode == 0 and error is None, stdout, stderr, error)
