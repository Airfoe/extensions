# i like to put values i need in multiple places here so i can change them in one place
import bpy  # type: ignore
import os
import tomllib # type: ignore


# has to be all lowercase
bl_id_prefix = "airfoe"

# suffix for the geo usd file a scene export writes next to the map file
MAP_GEO_SUFFIX = "_geo"

class AddonProperties:
    module_name = __package__
    panel_category = "Airfoe"


def get_manifest():
    toml_path = os.path.join(os.path.dirname(__file__), "blender_manifest.toml")
    with open(toml_path, "rb") as f:
        manifest = tomllib.load(f)
    return manifest


def get_export_root():
    from pathlib import Path
    root_path = bpy.context.scene.export_hook_settings.export_root_directory
    return Path(root_path)

def get_preferences():
    # No context needed, directly get addon preferences by package name
    addon_prefs = bpy.context.preferences.addons.get(__package__).preferences
    return addon_prefs


def get_operator(name):
    return bl_id_prefix + "." + name.lower()

